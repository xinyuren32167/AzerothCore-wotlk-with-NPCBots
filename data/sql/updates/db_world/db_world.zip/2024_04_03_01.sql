-- DB update 2024_04_03_00 -> 2024_04_03_01
--
UPDATE `creature` SET `spawntimesecs` = 60 WHERE  `guid` = 148735 AND `id1` = 23089;
