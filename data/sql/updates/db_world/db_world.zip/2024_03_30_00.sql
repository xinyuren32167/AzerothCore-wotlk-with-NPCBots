-- DB update 2024_03_24_09 -> 2024_03_30_00
-- update initial state of some Brazier gameobject spawns
UPDATE `gameobject` SET `state` = 1 WHERE (`id` = 174744) AND (`guid` = 15229);
UPDATE `gameobject` SET `state` = 1 WHERE (`id` = 174745) AND (`guid` = 15544);
UPDATE `gameobject` SET `state` = 1 WHERE (`id` = 178247) AND (`guid` = 47873);
