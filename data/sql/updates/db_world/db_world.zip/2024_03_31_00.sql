-- DB update 2024_03_30_01 -> 2024_03_31_00
--
UPDATE `reference_loot_template` SET `Item` = 30448, `Reference` = 0, `Chance` = 0, `Comment` = 'Talon of Al\'ar' WHERE `Entry` = 34053 AND `Item` = 1;
