-- DB update 2024_04_02_01 -> 2024_04_02_02
--
UPDATE `creature_template` SET `speed_walk` = 3.2, `speed_run` = 2.857142 WHERE (`entry` = 19516);
UPDATE `creature_model_info` SET `BoundingRadius` = 12.33326530456542968, `CombatReach` = 18 WHERE  `DisplayID` = 18951;
