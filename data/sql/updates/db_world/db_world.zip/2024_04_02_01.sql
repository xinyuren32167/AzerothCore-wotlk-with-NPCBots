-- DB update 2024_04_02_00 -> 2024_04_02_01
--
UPDATE `creature_loot_template` SET `MaxCount` = 2 WHERE `Entry` = 19622 AND `Item` = 90056 AND `Reference` = 34056 AND `GroupId` = 4;
